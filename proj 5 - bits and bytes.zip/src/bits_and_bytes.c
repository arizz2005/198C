#include <stdio.h>

void print_it() {
  // TODO
  printf("Bit operations are fun!\n");
}

void print_int() {
  // TODO
  int x = 10;
int y = 13;
int intType;
printf("x = %d\n", x);
printf("y = %d\n", y);
printf("size of signed int in bytes is %d.\n", sizeof(intType));
printf("size of signed int in bits is %d.\n", sizeof(intType)*8);
printf("%d + %d = %d.\n", x,y,(x+y));
}

void print_float() {
  // TODO
float x = 10;
float y = 13;
int intType;
printf("x = %.6f\n", x);
printf("y = %.6f\n", y);
printf("size of single float in bytes is %d.\n", sizeof(intType));
printf("size of single float in bits is %d.\n", sizeof(intType)*8);
printf("%.6f + %.6f = %.6f.\n", x,y,(x+y));
printf("%.6f + %.6f = %.0f.\n", x,y,(x+y));
}
void print_char() {
  // TODO
char c = 'C';
char a = 65;
char f = 'F';
char e = 69;
char b = 'B';
char str[] = "CAFEBABE";
printf("c = %c\n", c);
printf("a = %c\n", a);
printf("%c%c%c%c%c%c%c%c\n" , c,a,f,e,b,a,b,e);
printf("number of bytes: %zu.\n" ,sizeof(str));

}

void packing_bytes() {
// storing values in b0-b3
   unsigned char b3 = 202; 
   unsigned char b2 = 254;
   unsigned char b1 = 186; // rewrite all of this 
  unsigned char b0 = 190;
  unsigned int u = 0;
unsigned int temp = 0;
temp = (b3 & 255) << 24; 
u = u|temp;
temp = 0;
temp = (b2&255) << 16; 
u = u|temp;

temp = (b1&255)<<8;
u = u|temp;
temp = 0;

temp = (b0 & 255);
u = u|temp;
temp = 0;
printf("%X\n",u);
}

void unpacking_bytes() {
unsigned int i1 = 1835098984u;
unsigned int i2 = 1768842611u;
char c1 = i1 >> 24;
char c2 = i1 >>16;
char c3 = i1 >> 8;
char c4 = i1 >> 0;
char c5 = i2 >>24;
char c6 = i2 >>16;
char c7 = i2 >>8;
char c8 = i2 >>0;
char string[] = {c1, c2, c3, c4, c5, c6, c7, c8, 0};
printf("%s\n", string);
}

void print_bits() {

  unsigned char c = 181;
for (int i = 7; i >= 0; i--)
printf("%d", (c>>i)& 1);
printf("\n");
c= -75;
for (int i = 7; i >= 0; i--)
printf("%d", (c>>i) & 1);
printf("\n");
}

void extracting_fields() {
 
unsigned int a = 0xCAFEBABE;
  
  unsigned int b = a >> 29;
  unsigned int c = (a << 3) >> 28;
  unsigned int d = (a << 7) >> 28;
  unsigned int e = (a << 11) >> 29;
  unsigned int f = (a << 14) >> 29;
  unsigned int g = (a << 17) >> 28;
  unsigned int h = (a << 21) >> 28;
  unsigned int i = (a << 25) >> 29;
  unsigned int j = (a << 28) >> 30;
  unsigned int k = (a << 30) >> 30;

  printf("%d %d %d %d %d %d %d %d %d %d\n",b,c,d,e,f,g,h,i,j,k);
}

void updating_fields() {
unsigned int u = 17512807u;
unsigned int mask = 0xFFFFFFFF;
u &= ~((0xF << 18) | (0x1F << 10));
u |= (8 << 18) | (17 << 10);
printf("%08X\n", u);
}
